using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace DFSAlgorithmMaze
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		// maze array

		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;
		private System.Drawing.Printing.PrintDocument printDocument1;
		private System.Windows.Forms.PrintPreviewDialog printPreviewDialog1;
		private System.Windows.Forms.MainMenu mainMenu1;
		private System.Windows.Forms.MenuItem menuItem1;
		private System.Windows.Forms.MenuItem PrintMenu;
		private System.Windows.Forms.MenuItem PreviewMenu;
		private System.Windows.Forms.MenuItem DimensionsMenu;
		private Maze TheMaze  = new Maze();

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();
			SetBounds(this.Left, this.Top, (Maze.kDimension + 2) * Cell.kCellSize + Cell.kPadding , (Maze.kDimension + 5) * Cell.kCellSize + Cell.kPadding);
			this.Cursor = Cursors.WaitCursor;
			TheMaze.Generate();
			this.Cursor = Cursors.Arrow;

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(Form1));
			this.printDocument1 = new System.Drawing.Printing.PrintDocument();
			this.printPreviewDialog1 = new System.Windows.Forms.PrintPreviewDialog();
			this.mainMenu1 = new System.Windows.Forms.MainMenu();
			this.menuItem1 = new System.Windows.Forms.MenuItem();
			this.PrintMenu = new System.Windows.Forms.MenuItem();
			this.PreviewMenu = new System.Windows.Forms.MenuItem();
			this.DimensionsMenu = new System.Windows.Forms.MenuItem();
			// 
			// printDocument1
			// 
			this.printDocument1.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.printDocument1_PrintPage);
			// 
			// printPreviewDialog1
			// 
			this.printPreviewDialog1.AutoScrollMargin = new System.Drawing.Size(0, 0);
			this.printPreviewDialog1.AutoScrollMinSize = new System.Drawing.Size(0, 0);
			this.printPreviewDialog1.ClientSize = new System.Drawing.Size(400, 300);
			this.printPreviewDialog1.Document = this.printDocument1;
			this.printPreviewDialog1.Enabled = true;
			this.printPreviewDialog1.Icon = ((System.Drawing.Icon)(resources.GetObject("printPreviewDialog1.Icon")));
			this.printPreviewDialog1.Location = new System.Drawing.Point(148, 17);
			this.printPreviewDialog1.MaximumSize = new System.Drawing.Size(0, 0);
			this.printPreviewDialog1.Name = "printPreviewDialog1";
			this.printPreviewDialog1.Opacity = 1;
			this.printPreviewDialog1.TransparencyKey = System.Drawing.Color.Empty;
			this.printPreviewDialog1.Visible = false;
			// 
			// mainMenu1
			// 
			this.mainMenu1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.menuItem1});
			// 
			// menuItem1
			// 
			this.menuItem1.Index = 0;
			this.menuItem1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.DimensionsMenu,
																					  this.PrintMenu,
																					  this.PreviewMenu});
			this.menuItem1.Text = "File";
			// 
			// PrintMenu
			// 
			this.PrintMenu.Index = 1;
			this.PrintMenu.Text = "Print";
			this.PrintMenu.Click += new System.EventHandler(this.PrintMenu_Click);
			// 
			// PreviewMenu
			// 
			this.PreviewMenu.Index = 2;
			this.PreviewMenu.Text = "Print Preview...";
			this.PreviewMenu.Click += new System.EventHandler(this.PreviewMenu_Click);
			// 
			// DimensionsMenu
			// 
			this.DimensionsMenu.Index = 0;
			this.DimensionsMenu.Text = "Generate New Maze...";
			this.DimensionsMenu.Click += new System.EventHandler(this.DimensionsMenu_Click);
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(292, 273);
			this.Menu = this.mainMenu1;
			this.Name = "Form1";
			this.Text = "Depth First Search Maze";
			this.Paint += new System.Windows.Forms.PaintEventHandler(this.Form1_Paint);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void Form1_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
			Graphics g = e.Graphics;
		    g.FillRectangle(Brushes.White, ClientRectangle);
			TheMaze.Draw(g);		
		}

		private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
		{
			TheMaze.Draw(e.Graphics);		
		}

		private void PreviewMenu_Click(object sender, System.EventArgs e)
		{
		 this.printPreviewDialog1.ShowDialog();
		}

		private void PrintMenu_Click(object sender, System.EventArgs e)
		{
		  printDocument1.Print();
		}

		private void DimensionsMenu_Click(object sender, System.EventArgs e)
		{
			DimensionsDialog theDialog = new DimensionsDialog();
			theDialog.numericUpDown1.Value = Maze.kDimension;
			theDialog.numericUpDown2.Value = Cell.kCellSize;
			if (theDialog.ShowDialog() == DialogResult.OK)
			{
				Maze.kDimension = 	(int)theDialog.numericUpDown1.Value;
				Cell.kCellSize =  (int)theDialog.numericUpDown2.Value;
				TheMaze.Initialize();
				TheMaze.Generate();
				SetBounds(this.Left, this.Top, (Maze.kDimension + 2) * Cell.kCellSize + Cell.kPadding, (Maze.kDimension + 5) * Cell.kCellSize + Cell.kPadding);
				Invalidate();
			}
		}
	}
}
