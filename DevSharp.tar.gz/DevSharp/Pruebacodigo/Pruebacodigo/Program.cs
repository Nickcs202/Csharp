﻿/*
 * Creado por SharpDevelop.
 * Usuario: usuario
 * Fecha: 23/05/2017
 * Hora: 04:13 p.m.
 * 
 * Para cambiar esta plantilla use Herramientas | Opciones | Codificación | Editar Encabezados Estándar
 */
using System;
using System.Collections;

namespace Pruebacodigo
{
	class Program
	{
		public static ArrayList lista=new ArrayList();
		public static void Main(string[] args)
		{
			Console.WriteLine("Hello World!");
			
			// TODO: Implement Functionality Here
			
			
			
			lista.Add("A");
			lista.Add("B");
			lista.Add("C");
			Console.WriteLine("<>"+lista.Capacity);
			//Console.WriteLine(lista[1]);
			Console.WriteLine(m(1));
			
			Console.Write("Press any key to continue . . . ");
			Console.ReadKey(true);
		}
		public static string m(int n){
			/*string s="";
			foreach(var elem in lista){
				s= elem.ToString();
			}
			return s;*/
			//for(int i=0;i<((lista.Capacity));i++){
				return ""+lista[n];
				
			//}
		}
	}
}