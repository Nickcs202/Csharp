﻿/*
 * Creado por SharpDevelop.
 * Usuario: usuario
 * Fecha: 23/05/2017
 * Hora: 08:28 p.m.
 * 
 * Para cambiar esta plantilla use Herramientas | Opciones | Codificación | Editar Encabezados Estándar
 */
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace ListaLibro
{
	/// <summary>
	/// Description of MainForm.
	/// </summary>
	public partial class MainForm : Form
	{
		public MainForm()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
		
		
			Libro libro1=new Libro("Juan P.","El sol");
			Libro libro2=new Libro("Pedro J.","La Luna");
			Libro libro3=new Libro("Julio V.","23000 lenguas");
			Libro libro4=new Libro("Luis P.","Marte");
			
			public static Biblioteca biblio = new Biblioteca();
		
		
		void CargarClick(object sender, EventArgs e)
		{
			biblio.AddLibro (libro1);
			biblio.AddLibro (libro2);
			biblio.AddLibro (libro3);
			biblio.AddLibro (libro4);
		}
		void OrdenarClick(object sender, EventArgs e)
		{
	biblio.Ordenar();
		}
		void MostrarClick(object sender, EventArgs e)
		{
			Pantalla.Text="";
			foreach(var elem in biblio){
				Pantalla.Text += elem.ToString();
			}
	
		}
	}
}
