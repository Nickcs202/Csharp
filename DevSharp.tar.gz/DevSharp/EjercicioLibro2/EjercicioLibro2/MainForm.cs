﻿/*
 * Creado por SharpDevelop.
 * Usuario: usuario
 * Fecha: 22/05/2017
 * Hora: 11:53 p.m.
 * 
 * Para cambiar esta plantilla use Herramientas | Opciones | Codificación | Editar Encabezados Estándar
 */
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace EjercicioLibro2
{
	/// <summary>
	/// Description of MainForm.
	/// </summary>
	public partial class MainForm : Form
	{
		public MainForm()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
		
			Libro libro1=new Libro("Juan P.","El sol");
			Libro libro2=new Libro("Pedro J.","La Luna");
			Libro libro3=new Libro("Julio V.","23000 lenguas");
			Libro libro4=new Libro("Luis P.","Marte");
			
			public static Biblioteca biblio = new Biblioteca();
			//static biblio.Agregar(libro1);
			
			
			
		void AceptarClick(object sender, EventArgs e)
		{
			
		 	biblio.Agregar(libro1);
			biblio.Agregar(libro2);
			biblio.Agregar(libro3);
			biblio.Agregar(libro4);
					 	
			
			//Pantalla.Text+="";
		}
		void MostrarClick(object sender, EventArgs e)
		{
	Pantalla.Text="";
	/*int cont=0;
	while(cont<biblio.Cantidad){
		Pantalla.Text+=biblio.ToString;
		cont++;
	}*/
	//for(int i=0;i<4;i++){
	//Pantalla.Text+=biblio[0];
	//}
	int t= biblio.Tamanio();
	for(int i=0; i < t; i++){

	Pantalla.Text += biblio.MostrarLibros(i);
	}
		}
		void OrdenarClick(object sender, EventArgs e)
		{
			biblio.Ordenar();
		}
			
		
			
	}
}
