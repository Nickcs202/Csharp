﻿/*
 * Creado por SharpDevelop.
 * Usuario: usuario
 * Fecha: 22/05/2017
 * Hora: 11:54 p.m.
 * 
 * Para cambiar esta plantilla use Herramientas | Opciones | Codificación | Editar Encabezados Estándar
 */
using System;
using System.Collections;


namespace EjercicioLibro2
{
	/// <summary>
	/// Description of Biblioteca.
	/// </summary>
	public class Biblioteca
	{
		private static ArrayList dato;
		
		public Biblioteca()
		{
			dato=new ArrayList();
		}

		// disable once ConvertToAutoProperty
		public ArrayList Dato {
			get {
				return dato;
			}
			set {
				dato = value;
			}
		}
		
		public void Agregar(Libro libro){
			dato.Add(libro);
		}
		public void Eliminar(Libro libro){
			dato.Remove(libro);
		}
		public bool Buscar(Libro libro){
			return dato.Contains(libro);
		}
		public int Cantidad(){
			return dato.Count;
		}/*
		public ArrayList Obtener(){
			return dato.ToArray;
		}*/
		public int Tamanio(){
			return dato.Capacity;
		}
		
		public string MostrarLibros(int n){
			//foreach(var iten in dato){
			//for(int i=0;i<dato.Capacity;i++){
				//return iten.ToString();
				return ""+dato[n];
			//}
		}
		 /*  public static void PrintValues( IEnumerable myList )  {
      foreach ( Object obj in dato )
      	obj.ToString;
   }*/
		public void Ordenar(){
			Dato.Sort();
		}
		
		public override string ToString()
		{
			return "Biblioteca Dato="+ Dato.ToString();
		}

	}
}
