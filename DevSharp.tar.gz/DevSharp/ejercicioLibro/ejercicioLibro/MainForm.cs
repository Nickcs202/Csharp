﻿/*
 * Created by SharpDevelop.
 * User: usuario
 * Date: 22/05/2017
 * Time: 01:40 a.m.
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Security.Cryptography.X509Certificates;
using System.Windows.Forms;
using System.Collections;


namespace ejercicioLibro
{
	/// <summary>
	/// Description of MainForm.
	/// </summary>
	public partial class MainForm : Form
	{
		
		
			Libro libro1=new Libro("Juan P.","El sol");
			Libro libro2=new Libro("Pedro J.","La Luna");
			Libro libro3=new Libro("Julio V.","23000 lenguas");
			Libro libro4=new Libro("Luis P.","Marte");
			
			public static Libro[] biblioteca = new Libro[4];
			public static Libro[] biblioteca2;
			

		
		public MainForm()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
			

			
			
			
		}
		void MainFormLoad(object sender, EventArgs e)
		{
	
		}
		void Button1Click(object sender, EventArgs e)
		{/*
			ArrayList lista = new ArrayList();
			Libro libro1=new Libro("Juan P.","El sol");
			lista.Add(libro1);
			Libro libro2=new Libro("Pedro J.","La Luna");
			lista.Add(libro2);	
			Libro libro3=new Libro("Julio V.","23000 lenguas");
			lista.Add(libro3);
			Libro libro4=new Libro("Luis P.","Marte");
			lista.Add(libro4);
			
			foreach(var elm in lista) {
			pantalla.Text += elm.ToString();
	
			}*/

			//pantalla.ClearUndo;
			//pantalla.Text= Empty;
		biblioteca[0]=libro1;
		biblioteca[1]=libro2;
		biblioteca[2]=libro3;
		biblioteca[3]=libro4;
			
			
			
		}
		void PantallaTextChanged(object sender, EventArgs e)
		{
	
		}
		void Button2Click(object sender, EventArgs e)
		{
			Array.Sort(biblioteca);
			
			
		}
		void MostrarClick(object sender, EventArgs e)
		{
			pantalla.Text="";
			foreach(var elm in biblioteca) {
			pantalla.Text += elm.ToString();
			}
		}
	}
}
