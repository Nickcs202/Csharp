﻿/*
 * Creado por SharpDevelop.
 * Usuario: usuario
 * Fecha: 26/05/2017
 * Hora: 12:48 a.m.
 * 
 * Para cambiar esta plantilla use Herramientas | Opciones | Codificación | Editar Encabezados Estándar
 */
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using System.IO;

namespace FileVentana
{
	/// <summary>
	/// Description of MainForm.
	/// </summary>
	public partial class MainForm : Form
	{
		public MainForm()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
		void Panel2Paint(object sender, PaintEventArgs e)
		{
	
		}
		void Button1Click(object sender, EventArgs e)
		{
			//string path ="@"+ textBox1.Text.ToString();
			//string path =@"/tmp/guest-vayptb/Plantillas/";
			string path =textBox1.Text.ToString();
			FileInfo fileI = new FileInfo (path);
			listBox1.Items.Clear();
			listBox1.Items.Add(fileI.CreationTime);
			//listBox1.Items.Add(path);
		}
	}
}
