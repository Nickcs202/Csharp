﻿/*
 * Creado por SharpDevelop.
 * Usuario: usuario
 * Fecha: 26/05/2017
 * Hora: 10:32 a.m.
 * 
 * Para cambiar esta plantilla use Herramientas | Opciones | Codificación | Editar Encabezados Estándar
 */
using System;
using System.IO;

namespace PruebaCodigos
{
	class Program
	{
		public static void Main(string[] args)
		{
			Console.WriteLine("Hello World!");
			
			// TODO: Implement Functionality Here
			
			Console.Write("Press any key to continue . . . ");
			string path = "@C:\Users\usuario\Pictures";
			File f= new File(path);
						
		
			
			
			
			Console.ReadKey(true);
		}
	}
}