﻿/*
 * Created by SharpDevelop.
 * User: usuario
 * Date: 22/05/2017
 * Time: 01:40 a.m.
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
namespace ejercicioLibro
{
	partial class MainForm
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.TextBox pantalla;
		private System.Windows.Forms.Button button2;
		private System.Windows.Forms.Button Mostrar;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			this.button1 = new System.Windows.Forms.Button();
			this.pantalla = new System.Windows.Forms.TextBox();
			this.button2 = new System.Windows.Forms.Button();
			this.Mostrar = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// button1
			// 
			this.button1.BackColor = System.Drawing.SystemColors.ActiveBorder;
			this.button1.ForeColor = System.Drawing.SystemColors.WindowText;
			this.button1.Location = new System.Drawing.Point(185, 220);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(75, 23);
			this.button1.TabIndex = 0;
			this.button1.Text = "Iniciar";
			this.button1.UseVisualStyleBackColor = false;
			this.button1.Click += new System.EventHandler(this.Button1Click);
			// 
			// pantalla
			// 
			this.pantalla.Location = new System.Drawing.Point(24, 12);
			this.pantalla.Multiline = true;
			this.pantalla.Name = "pantalla";
			this.pantalla.Size = new System.Drawing.Size(236, 164);
			this.pantalla.TabIndex = 1;
			this.pantalla.TextChanged += new System.EventHandler(this.PantallaTextChanged);
			// 
			// button2
			// 
			this.button2.Location = new System.Drawing.Point(24, 220);
			this.button2.Name = "button2";
			this.button2.Size = new System.Drawing.Size(75, 23);
			this.button2.TabIndex = 2;
			this.button2.Text = "Ordenar";
			this.button2.UseVisualStyleBackColor = true;
			this.button2.Click += new System.EventHandler(this.Button2Click);
			// 
			// Mostrar
			// 
			this.Mostrar.Location = new System.Drawing.Point(105, 220);
			this.Mostrar.Name = "Mostrar";
			this.Mostrar.Size = new System.Drawing.Size(75, 23);
			this.Mostrar.TabIndex = 3;
			this.Mostrar.Text = "Mostrar";
			this.Mostrar.UseVisualStyleBackColor = true;
			this.Mostrar.Click += new System.EventHandler(this.MostrarClick);
			// 
			// MainForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(282, 255);
			this.Controls.Add(this.Mostrar);
			this.Controls.Add(this.button2);
			this.Controls.Add(this.pantalla);
			this.Controls.Add(this.button1);
			this.Name = "MainForm";
			this.Text = "ejercicioLibro";
			this.Load += new System.EventHandler(this.MainFormLoad);
			this.ResumeLayout(false);
			this.PerformLayout();

		}
	}
}
