﻿/*
 * Created by SharpDevelop.
 * User: usuario
 * Date: 22/05/2017
 * Time: 01:47 a.m.
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace ejercicioLibro
{
	/// <summary>
	/// Description of IColeccionable.
	/// </summary>
	public interface IColeccionable
	{
		string Titulo{set;get;}
		
		//string Describir();
		
	}
}
