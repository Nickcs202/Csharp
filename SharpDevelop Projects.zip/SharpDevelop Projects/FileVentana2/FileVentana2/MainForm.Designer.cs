﻿/*
 * Creado por SharpDevelop.
 * Usuario: usuario
 * Fecha: 26/05/2017
 * Hora: 05:42 p.m.
 * 
 * Para cambiar esta plantilla use Herramientas | Opciones | Codificación | Editar Encabezados Estándar
 */
namespace FileVentana2
{
	partial class MainForm
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		private System.Windows.Forms.Button Ver;
		private System.Windows.Forms.ListBox listBox1;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			this.Ver = new System.Windows.Forms.Button();
			this.listBox1 = new System.Windows.Forms.ListBox();
			this.SuspendLayout();
			// 
			// Ver
			// 
			this.Ver.Location = new System.Drawing.Point(23, 25);
			this.Ver.Name = "Ver";
			this.Ver.Size = new System.Drawing.Size(118, 50);
			this.Ver.TabIndex = 0;
			this.Ver.Text = "Buscar Carpeta";
			this.Ver.UseVisualStyleBackColor = true;
			this.Ver.Click += new System.EventHandler(this.VerClick);
			// 
			// listBox1
			// 
			this.listBox1.FormattingEnabled = true;
			this.listBox1.ItemHeight = 16;
			this.listBox1.Location = new System.Drawing.Point(23, 105);
			this.listBox1.Name = "listBox1";
			this.listBox1.Size = new System.Drawing.Size(636, 308);
			this.listBox1.TabIndex = 1;
			// 
			// MainForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(684, 428);
			this.Controls.Add(this.listBox1);
			this.Controls.Add(this.Ver);
			this.Name = "MainForm";
			this.Text = "FileVentana2";
			this.ResumeLayout(false);

		}
	}
}
