﻿/*
 * Creado por SharpDevelop.
 * Usuario: usuario
 * Fecha: 26/05/2017
 * Hora: 05:42 p.m.
 * 
 * Para cambiar esta plantilla use Herramientas | Opciones | Codificación | Editar Encabezados Estándar
 */
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using System.IO;

namespace FileVentana2
{
	/// <summary>
	/// Description of MainForm.
	/// </summary>
	public partial class MainForm : Form
	{
		public MainForm()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
		void VerClick(object sender, EventArgs e)
		{
			FolderBrowserDialog fbd= new FolderBrowserDialog();
			
			if(fbd.ShowDialog() == DialogResult.OK){
				listBox1.Items.Clear();
				string[] files = Directory.GetFiles(fbd.SelectedPath);
				string[] dir = Directory.GetDirectories (fbd.SelectedPath);
				FileInfo fi=new FileInfo(fbd.SelectedPath);
				
				
				listBox1.Items.Add(Path.GetDirectoryName(fbd.SelectedPath));
				
				foreach(string s in files){
					listBox1.Items.Add("\t"+Path.GetFileName (s)+"\t\t"+fi.CreationTime);
				}
				foreach(string d in dir){
					listBox1.Items.Add("\t"+Path.GetFileName (d)+"\t\t"+fi.CreationTime);
				}
				
			}
		}
	}
}
