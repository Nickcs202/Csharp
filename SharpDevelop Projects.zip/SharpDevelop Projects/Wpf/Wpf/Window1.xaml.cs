﻿/*
 * Creado por SharpDevelop.
 * Usuario: usuario
 * Fecha: 25/05/2017
 * Hora: 04:54 a.m.
 * 
 * Para cambiar esta plantilla use Herramientas | Opciones | Codificación | Editar Encabezados Estándar
 */
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;

namespace Wpf
{
	/// <summary>
	/// Interaction logic for Window1.xaml
	/// </summary>
	public partial class Window1 : Window
	{
		static string s="";
		public Window1()
		{
			InitializeComponent();
		}
		void Aceptar_Click(object sender, RoutedEventArgs e)
		{
			
			Pantalla.Text ="";
			Pantalla.Text +=""+ s;
		}
		void Pantalla2_TextInput(object sender, TextCompositionEventArgs e)
		{
			s=(string) sender;
		}
	}
}