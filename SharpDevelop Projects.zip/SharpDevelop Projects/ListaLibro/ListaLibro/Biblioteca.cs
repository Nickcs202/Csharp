﻿/*
 * Creado por SharpDevelop.
 * Usuario: usuario
 * Fecha: 23/05/2017
 * Hora: 08:29 p.m.
 * 
 * Para cambiar esta plantilla use Herramientas | Opciones | Codificación | Editar Encabezados Estándar
 */
using System;
using System.Collections;

namespace ListaLibro
{
	/// <summary>
	/// Description of Biblioteca.
	/// </summary>
	public class Biblioteca : IEnumerable
	{
		
		private ArrayList listaLibros= new ArrayList();
		
		public Biblioteca()
		{
		}
		
		public Libro GetLibros(int pos){
			return (Libro)listaLibros[pos];
		}
		public void AddLibro(Libro l){
			listaLibros.Add(l);
		}
		public void ClearLibro(){
			listaLibros.Clear();
	}
			public void Ordenar(){
			listaLibros.Sort();
		}

		#region IEnumerable implementation

		public IEnumerator GetEnumerator()
		{
			return listaLibros.GetEnumerator();
		}

		#endregion
	}
}
