﻿/*
 * Creado por SharpDevelop.
 * Usuario: usuario
 * Fecha: 23/05/2017
 * Hora: 10:11 p.m.
 * 
 * Para cambiar esta plantilla use Herramientas | Opciones | Codificación | Editar Encabezados Estándar
 */
using System;

namespace EjercicioTimeSort
{
	/// <summary>
	/// Description of IColeccionable.
	/// </summary>
	public interface IColeccionable
	{
				string Titulo{set;get;}
		
		//string Describir();
	}
}
