﻿/*
 * Creado por SharpDevelop.
 * Usuario: usuario
 * Fecha: 23/05/2017
 * Hora: 10:10 p.m.
 * 
 * Para cambiar esta plantilla use Herramientas | Opciones | Codificación | Editar Encabezados Estándar
 */
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using System.Collections;
using System.Diagnostics;
using System.Threading;


namespace EjercicioTimeSort
{
	/// <summary>
	/// Description of MainForm.
	/// </summary>
	public partial class MainForm : Form
	{
		public MainForm()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
		void MainFormLoad(object sender, EventArgs e)
		{/*
				arrayList.Add(libro1);
			arrayList.Add(libro2);
			arrayList.Add(libro3);
			arrayList.Add(libro4);	
			arrayList.Add(libro5);
			arrayList.Add(libro6);
			arrayList.Add(libro7);
			arrayList.Add(libro8);
			arrayList.Add(libro9);
			arrayList.Add(libro10);
			arrayList.Add(libro11);
			arrayList.Add(libro12);
			arrayList.Add(libro13);
			arrayList.Add(libro14);
			arrayList.Add(libro15);
			arrayList.Add(libro16);
			arrayList.Add(libro17);
			arrayList.Add(libro18);
			arrayList.Add(libro19);
			arrayList.Add(libro20);	
			arrayList.Add(libro21);
			arrayList.Add(libro22);
			arrayList.Add(libro23);
			arrayList.Add(libro24);
			arrayList.Add(libro25);
			arrayList.Add(libro26);
			arrayList.Add(libro27);
			arrayList.Add(libro28);
			arrayList.Add(libro29);
			arrayList.Add(libro30);
			arrayList.Add(libro31);
			arrayList.Add(libro32);
			
	
			array[1]=libro1;
			array[2]=libro2;
			array[3]=libro3;
			array[4]=libro4;
			array[5]=libro5;
			array[6]=libro6;
			array[7]=libro7;
			array[8]=libro8;
		    array[9]=libro9;
			array[10]=libro10;
			array[11]=libro11;
			array[12]=libro12;
			array[13]=libro13;
			array[14]=libro14;
			array[15]=libro15;
			array[16]=libro16;	
			array[17]=libro1;
			array[18]=libro2;
			array[19]=libro3;
			array[29]=libro4;
			array[21]=libro5;
			array[22]=libro6;
			array[23]=libro7;
			array[24]=libro8;
		    array[25]=libro9;
			array[26]=libro10;
			array[27]=libro11;
			array[28]=libro12;
			array[29]=libro13;
			array[30]=libro14;
			array[31]=libro15;
			array[32]=libro16;			
			
			
			list.Add(libro1);
			list.Add(libro2);
			list.Add(libro3);
			list.Add(libro4);
			list.Add(libro5);
			list.Add(libro6);
			list.Add(libro7);
			list.Add(libro8);
			list.Add(libro9);
			list.Add(libro10);
			list.Add(libro11);
			list.Add(libro12);
			list.Add(libro13);
			list.Add(libro14);
			list.Add(libro15);
			list.Add(libro16);
			list.Add(libro17);
			list.Add(libro18);
			list.Add(libro19);
			list.Add(libro20);
			list.Add(libro21);
			list.Add(libro22);
			list.Add(libro23);
			list.Add(libro24);
			list.Add(libro25);
			list.Add(libro26);
			list.Add(libro27);
			list.Add(libro28);
			list.Add(libro29);
			list.Add(libro30);
			list.Add(libro31);
			list.Add(libro32);*/
		}
		
	static		Libro libro1=new Libro("Juan P.","El sol");
	static		Libro libro2=new Libro("Pedro J.","La Luna");
	static		Libro libro3=new Libro("Julio V.","23000 lenguas");
	static		Libro libro4=new Libro("Luis P.","Marte");
	static		Libro libro5=new Libro("Tito G.","El sol");
	static		Libro libro6=new Libro("Antonio L.","La Luna");
	static		Libro libro7=new Libro("Ravat T.","23000 lenguas");
	static		Libro libro8=new Libro("Ernesto C.","Marte");
	static		Libro libro9=new Libro("Xilofont Ñ.","El sol");
	static		Libro libro10=new Libro("Goustav E.","La Luna");
	static		Libro libro11=new Libro("Petinat R.","23000 lenguas");
	static		Libro libro12=new Libro("Bon H.","Marte");	
	static		Libro libro13=new Libro("Jeans B.","El sol");
	static		Libro libro14=new Libro("Biel S.","La Luna");
	static		Libro libro15=new Libro("Mac G.","23000 lenguas");
	static		Libro libro16=new Libro("Luisdelydsf O.","Marte");
	static		Libro libro17=new Libro("FSDF D.","El sol");
	static		Libro libro18=new Libro("Psdf.","La Luna");
	static		Libro libro19=new Libro("SAFsdf V.","23000 lenguas");
	static		Libro libro20=new Libro("assdf D.","Marte");
	static		Libro libro21=new Libro("Fajkasdjk DS.","El sol");
	static		Libro libro22=new Libro("FKhdjkd L.","La Luna");
	static		Libro libro23=new Libro("ÑKfgkk.","23000 lenguas");
	static		Libro libro24=new Libro("Ldskgjh C.","Marte");
	static		Libro libro25=new Libro("Zxsfhjg jkhg.","El sol");
	static		Libro libro26=new Libro("RThk.","La Luna");
	static		Libro libro27=new Libro("P.","23000 lenguas");
	static		Libro libro28=new Libro("SAdfklshdjk.","Marte");	
	static		Libro libro29=new Libro("Ujsj.","El sol");
	static		Libro libro30=new Libro("Qiel S.","La Luna");
	static		Libro libro31=new Libro("vjh.","23000 lenguas");
	static		Libro libro32=new Libro("Ymfnj.","Marte");
	
	
			//public static ArrayList arrayList;
			//public static List<Libro> list;
			//public static Libro[] array;
			
			
		void Button1Click(object sender, EventArgs e)
		{
			
			Libro[] array=new Libro[33];
			
			
			array[1]=libro1;
			array[2]=libro2;
			array[3]=libro3;
			array[4]=libro4;
			array[5]=libro5;
			array[6]=libro6;
			array[7]=libro7;
			array[8]=libro8;
		    array[9]=libro9;
			array[10]=libro10;
			array[11]=libro11;
			array[12]=libro12;
			array[13]=libro13;
			array[14]=libro14;
			array[15]=libro15;
			array[16]=libro16;	
			array[17]=libro1;
			array[18]=libro2;
			array[19]=libro3;
			array[29]=libro4;
			array[21]=libro5;
			array[22]=libro6;
			array[23]=libro7;
			array[24]=libro8;
		    array[25]=libro9;
			array[26]=libro10;
			array[27]=libro11;
			array[28]=libro12;
			array[29]=libro13;
			array[30]=libro14;
			array[31]=libro15;
			array[32]=libro16;
			
			Stopwatch stopWatch = new Stopwatch();
			stopWatch.Start();
			//Thread.Sleep(1000);
			//arrayList.Sort();
			Array.Sort(array);
			//list.Sort();
			stopWatch.Stop();
			
			TimeSpan ts = stopWatch.Elapsed;
			
			string elapseTime = String.Format("{0:00}:{1:00}:{2:00}.{3:00}",ts.Hours,ts.Minutes, ts.Seconds, ts.Milliseconds/10);
			Pantalla.Text="";
			Pantalla.Text = ("RunTime "+elapseTime);
		}
		void Button2Click(object sender, EventArgs e)
		{
			List<Libro> list=new List<Libro>();
			
			list.Add(libro1);
			list.Add(libro2);
			list.Add(libro3);
			list.Add(libro4);
			list.Add(libro5);
			list.Add(libro6);
			list.Add(libro7);
			list.Add(libro8);
			list.Add(libro9);
			list.Add(libro10);
			list.Add(libro11);
			list.Add(libro12);
			list.Add(libro13);
			list.Add(libro14);
			list.Add(libro15);
			list.Add(libro16);
			list.Add(libro17);
			list.Add(libro18);
			list.Add(libro19);
			list.Add(libro20);
			list.Add(libro21);
			list.Add(libro22);
			list.Add(libro23);
			list.Add(libro24);
			list.Add(libro25);
			list.Add(libro26);
			list.Add(libro27);
			list.Add(libro28);
			list.Add(libro29);
			list.Add(libro30);
			list.Add(libro31);
			list.Add(libro32);
			
				Stopwatch stopWatch = new Stopwatch();
			stopWatch.Start();
			//Thread.Sleep(1000);
			//arrayList.Sort();
			//Array.Sort(array);
			list.Sort();
			stopWatch.Stop();
			
			TimeSpan ts = stopWatch.Elapsed;
			
			string elapseTime = String.Format("{0:00}:{1:00}:{2:00}.{3:00}",ts.Hours,ts.Minutes, ts.Seconds, ts.Milliseconds/10);
			Pantalla.Text="";
			Pantalla.Text = ("RunTime "+elapseTime);
		}
		void Button3Click(object sender, EventArgs e)
		{
			 ArrayList arrayList=new ArrayList();
			 
			 			arrayList.Add(libro1);
			arrayList.Add(libro2);
			arrayList.Add(libro3);
			arrayList.Add(libro4);	
			arrayList.Add(libro5);
			arrayList.Add(libro6);
			arrayList.Add(libro7);
			arrayList.Add(libro8);
			arrayList.Add(libro9);
			arrayList.Add(libro10);
			arrayList.Add(libro11);
			arrayList.Add(libro12);
			arrayList.Add(libro13);
			arrayList.Add(libro14);
			arrayList.Add(libro15);
			arrayList.Add(libro16);
			arrayList.Add(libro17);
			arrayList.Add(libro18);
			arrayList.Add(libro19);
			arrayList.Add(libro20);	
			arrayList.Add(libro21);
			arrayList.Add(libro22);
			arrayList.Add(libro23);
			arrayList.Add(libro24);
			arrayList.Add(libro25);
			arrayList.Add(libro26);
			arrayList.Add(libro27);
			arrayList.Add(libro28);
			arrayList.Add(libro29);
			arrayList.Add(libro30);
			arrayList.Add(libro31);
			arrayList.Add(libro32);
			 
				Stopwatch stopWatch = new Stopwatch();
			stopWatch.Start();
			//Thread.Sleep(1000);
			arrayList.Sort();
			//Array.Sort(array);
			//list.Sort();
			stopWatch.Stop();
			
			TimeSpan ts = stopWatch.Elapsed;
			
			string elapseTime = String.Format("{0:00}:{1:00}:{2:00}.{3:00}",ts.Hours,ts.Minutes, ts.Seconds, ts.Milliseconds/10);
			Pantalla.Text="";
			Pantalla.Text = ("RunTime "+elapseTime);
		}
		void Button4Click(object sender, EventArgs e)
		{/*
			arrayList.Add(libro1);
			arrayList.Add(libro2);
			arrayList.Add(libro3);
			arrayList.Add(libro4);	
			arrayList.Add(libro5);
			arrayList.Add(libro6);
			arrayList.Add(libro7);
			arrayList.Add(libro8);
			arrayList.Add(libro9);
			arrayList.Add(libro10);
			arrayList.Add(libro11);
			arrayList.Add(libro12);
			arrayList.Add(libro13);
			arrayList.Add(libro14);
			arrayList.Add(libro15);
			arrayList.Add(libro16);
			arrayList.Add(libro17);
			arrayList.Add(libro18);
			arrayList.Add(libro19);
			arrayList.Add(libro20);	
			arrayList.Add(libro21);
			arrayList.Add(libro22);
			arrayList.Add(libro23);
			arrayList.Add(libro24);
			arrayList.Add(libro25);
			arrayList.Add(libro26);
			arrayList.Add(libro27);
			arrayList.Add(libro28);
			arrayList.Add(libro29);
			arrayList.Add(libro30);
			arrayList.Add(libro31);
			arrayList.Add(libro32);
			
	
			array[1]=libro1;
			array[2]=libro2;
			array[3]=libro3;
			array[4]=libro4;
			array[5]=libro5;
			array[6]=libro6;
			array[7]=libro7;
			array[8]=libro8;
		    array[9]=libro9;
			array[10]=libro10;
			array[11]=libro11;
			array[12]=libro12;
			array[13]=libro13;
			array[14]=libro14;
			array[15]=libro15;
			array[16]=libro16;	
			array[17]=libro1;
			array[18]=libro2;
			array[19]=libro3;
			array[29]=libro4;
			array[21]=libro5;
			array[22]=libro6;
			array[23]=libro7;
			array[24]=libro8;
		    array[25]=libro9;
			array[26]=libro10;
			array[27]=libro11;
			array[28]=libro12;
			array[29]=libro13;
			array[30]=libro14;
			array[31]=libro15;
			array[32]=libro16;			
			
			
			list.Add(libro1);
			list.Add(libro2);
			list.Add(libro3);
			list.Add(libro4);
			list.Add(libro5);
			list.Add(libro6);
			list.Add(libro7);
			list.Add(libro8);
			list.Add(libro9);
			list.Add(libro10);
			list.Add(libro11);
			list.Add(libro12);
			list.Add(libro13);
			list.Add(libro14);
			list.Add(libro15);
			list.Add(libro16);
			list.Add(libro17);
			list.Add(libro18);
			list.Add(libro19);
			list.Add(libro20);
			list.Add(libro21);
			list.Add(libro22);
			list.Add(libro23);
			list.Add(libro24);
			list.Add(libro25);
			list.Add(libro26);
			list.Add(libro27);
			list.Add(libro28);
			list.Add(libro29);
			list.Add(libro30);
			list.Add(libro31);
			list.Add(libro32);
			*/
		}

	}
	
	
	
	
}
