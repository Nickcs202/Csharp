﻿/*
 * Creado por SharpDevelop.
 * Usuario: usuario
 * Fecha: 22/05/2017
 * Hora: 11:53 p.m.
 * 
 * Para cambiar esta plantilla use Herramientas | Opciones | Codificación | Editar Encabezados Estándar
 */

using System;


namespace EjercicioLibro2
{
	/// <summary>
	/// Description of Libro.
	/// </summary>
	public class Libro : IColeccionable, IComparable
	{
		private string titulo;
		private string autor;
		
		
		public Libro(string autor, string titulo)
		{
			this.autor=autor;
			this.titulo=titulo;
			
		}
		public string Autor{set{this.autor=value;}get{return this.autor;}}

		#region IColeccionable implementation

		public string Titulo {
			get {
				return this.titulo;
			}
			set {
				this.titulo=value;
			}
		}

		#endregion

		#region IComparable implementation

		public int CompareTo(object obj)
		{
			Libro aux = (Libro) obj;
			return this.Titulo.CompareTo(aux.Titulo);
		}

		#endregion
		
		public override string ToString()
		{
			return "Libro: Titulo= "+Titulo+" , Autor= "+Autor+"";
		}

	}
}
