﻿/*
 * Creado por SharpDevelop.
 * Usuario: usuario
 * Fecha: 22/05/2017
 * Hora: 11:55 p.m.
 * 
 * Para cambiar esta plantilla use Herramientas | Opciones | Codificación | Editar Encabezados Estándar
 */
using System;

namespace EjercicioLibro2
{
	/// <summary>
	/// Description of IColeccionable.
	/// </summary>
	public interface IColeccionable
	{
		string Titulo{set;get;}
		
		//string Describir();
	}
}
