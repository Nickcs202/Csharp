﻿/*
 * Creado por SharpDevelop.
 * Usuario: usuario
 * Fecha: 22/05/2017
 * Hora: 11:53 p.m.
 * 
 * Para cambiar esta plantilla use Herramientas | Opciones | Codificación | Editar Encabezados Estándar
 */
namespace EjercicioLibro2
{
	partial class MainForm
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		private System.Windows.Forms.TextBox Pantalla;
		private System.Windows.Forms.Button Ordenar;
		private System.Windows.Forms.Button Aceptar;
		private System.Windows.Forms.Button Mostrar;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			this.Pantalla = new System.Windows.Forms.TextBox();
			this.Ordenar = new System.Windows.Forms.Button();
			this.Aceptar = new System.Windows.Forms.Button();
			this.Mostrar = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// Pantalla
			// 
			this.Pantalla.Location = new System.Drawing.Point(37, 12);
			this.Pantalla.Multiline = true;
			this.Pantalla.Name = "Pantalla";
			this.Pantalla.Size = new System.Drawing.Size(422, 178);
			this.Pantalla.TabIndex = 0;
			// 
			// Ordenar
			// 
			this.Ordenar.Location = new System.Drawing.Point(25, 220);
			this.Ordenar.Name = "Ordenar";
			this.Ordenar.Size = new System.Drawing.Size(75, 23);
			this.Ordenar.TabIndex = 1;
			this.Ordenar.Text = "Ordenar";
			this.Ordenar.UseVisualStyleBackColor = true;
			this.Ordenar.Click += new System.EventHandler(this.OrdenarClick);
			// 
			// Aceptar
			// 
			this.Aceptar.Location = new System.Drawing.Point(184, 219);
			this.Aceptar.Name = "Aceptar";
			this.Aceptar.Size = new System.Drawing.Size(75, 23);
			this.Aceptar.TabIndex = 2;
			this.Aceptar.Text = "Iniciar";
			this.Aceptar.UseVisualStyleBackColor = true;
			this.Aceptar.Click += new System.EventHandler(this.AceptarClick);
			// 
			// Mostrar
			// 
			this.Mostrar.Location = new System.Drawing.Point(106, 220);
			this.Mostrar.Name = "Mostrar";
			this.Mostrar.Size = new System.Drawing.Size(75, 23);
			this.Mostrar.TabIndex = 3;
			this.Mostrar.Text = "Mostrar";
			this.Mostrar.UseVisualStyleBackColor = true;
			this.Mostrar.Click += new System.EventHandler(this.MostrarClick);
			// 
			// MainForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(497, 268);
			this.Controls.Add(this.Mostrar);
			this.Controls.Add(this.Aceptar);
			this.Controls.Add(this.Ordenar);
			this.Controls.Add(this.Pantalla);
			this.Name = "MainForm";
			this.Text = "EjercicioLibro2";
			this.ResumeLayout(false);
			this.PerformLayout();

		}
	}
}
