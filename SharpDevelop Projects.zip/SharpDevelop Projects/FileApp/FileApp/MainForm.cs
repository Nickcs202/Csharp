﻿/*
 * Creado por SharpDevelop.
 * Usuario: usuario
 * Fecha: 26/05/2017
 * Hora: 12:10 a.m.
 * 
 * Para cambiar esta plantilla use Herramientas | Opciones | Codificación | Editar Encabezados Estándar
 */
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using System.IO;

namespace FileApp
{
	/// <summary>
	/// Description of MainForm.
	/// </summary>
	public partial class MainForm : Form
	{
		private static string path;
		public MainForm()
		{
		
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
		void MainFormLoad(object sender, EventArgs e)
		{
	
		}
		void Panel1Paint(object sender, PaintEventArgs e)
		{
	
		}
		void VerInfToolStripMenuItemClick(object sender, EventArgs e)
		{
			FileInfo fileI = new FileInfo (path);
			//listBox1.Text =""+ fileI.CreationTime+fileI.Attributes;
			textBox2.Text=""+ fileI.CreationTime+fileI.Attributes;
		}
		void TextBox1TextChanged(object sender, EventArgs e)
		{
			path=textBox1.Text.ToString();
			
		}
		void TextBox2TextChanged(object sender, EventArgs e)
		{
	
		}

	}
}
