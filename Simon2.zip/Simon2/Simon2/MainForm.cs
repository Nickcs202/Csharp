﻿/*
 * Creado por SharpDevelop.
 * Usuario: usuario
 * Fecha: 06/05/2017
 * Hora: 23:24
 * 
 * Para cambiar esta plantilla use Herramientas | Opciones | Codificación | Editar Encabezados Estándar
 */
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using System.Threading;

namespace Simon2
{
	/// <summary>
	/// Description of MainForm.
	/// </summary>
	public partial class MainForm : Form
	{
		Simon sm=new Simon();
		int[,] matriz=new int[2,2];
		int[,] matriz2=new int[2,2]{{0,0},{0,0}};
		bool valor=true;
		public MainForm()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
		void Button5Click(object sender, EventArgs e)
		{
		matriz2=new int[2,2]{{0,0},{0,0}};
			//do{
			matriz= sm.matrizAleatoria();

				
					if(matriz [0,0]==1){
						button1.BackColor=Color.Green;
						
						button1.Refresh();
						button1.BackColor=Color.White;
						Thread.SpinWait (100000000);
				}
					if(matriz[0,1]==1){
						button4.BackColor=Color.Red;
						
						button4.Refresh();
						button4.BackColor=Color.White;
						Thread.SpinWait (100000000);
				}
					if(matriz[1,0]==1){
						button2.BackColor=Color.Yellow;
						
						button2.Refresh();
						button2.BackColor=Color.White;
						Thread.SpinWait (100000000);
				}
					if(matriz[1,1]==1){
						button3.BackColor=Color.Blue;
						
						button3.Refresh();
						button3.BackColor=Color.White;
						Thread.SpinWait (100000000);
				}
						

	//Thread.SpinWait (1000000000);
	//Thread.Sleep(1000);
	/*
	if(sm.esIgual(matriz,matriz2)){
		Thread.SpinWait (1000000000);
		
						button7.BackColor=Color.Green;
						button7.Refresh();
						button7.BackColor=Color.White;
						Thread.SpinWait (100000000);
	}else{
		Thread.SpinWait (1000000000);
						button7.BackColor=Color.Red;
						button7.Refresh();
						button7.BackColor=Color.White;
						Thread.SpinWait (100000000);
	}
*/

		//	}while(valor);
	
		}
		

		
		void Button6Click(object sender, EventArgs e)
		{
					if(sm.esIgual(matriz,matriz2)){
	//	Thread.SpinWait (1000000000);
		
						button7.BackColor=Color.Green;
						button7.Refresh();
						button7.BackColor=Color.White;
						Thread.SpinWait (100000000);
	}else{
		//Thread.SpinWait (1000000000);
						button7.BackColor=Color.Red;
						button7.Refresh();
						button7.BackColor=Color.White;
						Thread.SpinWait (100000000);
	}
			matriz2=new int[2,2]{{0,0},{0,0}};
		}
		void Button1Click(object sender, EventArgs e)
		{
			//sm.matrizUsuario(1,0,0);
			matriz2[0,0]=1;
		}
		void Button4Click(object sender, EventArgs e)
		{
	//sm.matrizUsuario(1,0,1);
	matriz2[0,1]=1;
		}
		void Button2Click(object sender, EventArgs e)
		{
	//sm.matrizUsuario(1,1,0);
	matriz2[1,0]=1;
		}
		void Button3Click(object sender, EventArgs e)
		{
	//sm.matrizUsuario(1,1,1);
	matriz2[1,1]=1;
		}

	}
}
