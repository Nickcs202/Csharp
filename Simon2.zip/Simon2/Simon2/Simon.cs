﻿/*
 * Creado por SharpDevelop.
 * Usuario: usuario
 * Fecha: 06/06/2017
 * Hora: 12:19 a.m.
 * 
 * Para cambiar esta plantilla use Herramientas | Opciones | Codificación | Editar Encabezados Estándar
 */
using System;
using System.Threading;

namespace Simon2
{
	/// <summary>
	/// Description of Simon.
	/// </summary>
	public class Simon
	{
		public static Random rdm = new Random ();
		public static int[,] matriz = new int[2, 2];

		
		public Simon()
		{
		}
		
		public int[,] matrizAleatoria ()
		{
			//int[,] matriz=new int[2,2];
				for (int i = 0; i < matriz.GetLength (0); i++) {
				for (int j = 0; j < matriz.GetLength (1); j++) {
					matriz [i, j] = rdm.Next (0, 2);
					Thread.SpinWait (10000000);
				}

			}
			return matriz;

		}

		public  int mostrarMatriz (int [,] mat, int i, int j)
		{


		//	for (int i = 0; i < mat.GetLength (0); i++) {
		//		for (int j = 0; j < mat.GetLength (1); j++) {
				return	( matriz [i, j]);
				//}
			//}
		}

		public bool esIgual (int[,] mA, int[,] mB)
		{
			//bool variable = false;

			return (mA [0, 0] == mB [0, 0] & mA [0, 1] == mB [0, 1] & mA [1, 0] == mB [1, 0] & mA [1, 1] == mB [1, 1]);
		}

		public int[,] matrizUsuario (int n, int i, int j)
		{
			int[,] matz =new int[2,2]{{0,0},{0,0}};

			//for (int i = 0; i < matz.GetLength (0); i++) {
			//	for (int j = 0; j < matz.GetLength (1); j++) {
				//	Console.WriteLine ("Ingrese numero");
					//matz [i, j] =Int32.Parse ( Console.ReadLine ());
			//	}
			//}
			
			matz[i,j]=n;
			return matz;
		
		}
	}
}
